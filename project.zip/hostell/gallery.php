<?php include('header.php')?>
 
	<!--gallery-->
<div class="gallery">
	<div class="container">
		<div class="gallery-top">
			<h2>Image Available in My College</h2>
			<p> There are many variations of Image.....</p>
		</div>
            <ul class="simplefilter">
                <li class="active" data-filter="all">All</li>
                <li data-filter="1">Category</li>
                <li data-filter="2">Category1</li>
                <li data-filter="3">Category2</li>
                <li data-filter="4">Category3</li>
                <li data-filter="5">Category4</li>
            </ul>
     
            <div class="filtr-container">
                <div class=" col-md-4 filtr-item" data-category="1, 5" data-sort="Busy streets">
                  <a href="images/pc.jpg" class="b-link-stripe b-animate-go  swipebox">
					<div class="ed-gal-effect slow-zoom horizontal">
						<div class="img-box"><img src="images/pc.jpg" alt=" " /></div>
							<div class="ed-text-box">
								<div class="ed-gal-text">
									<h4>Hostel</h4>
									<p>It has been a wonderful stay here! It was a relaxing, laugher-filled stay with some amazing people!</p>
								</div>
							</div>
					</div>
				</a>

                </div>
                <div class="col-md-4 filtr-item" data-category="2, 5" data-sort="Luminous night">
                    <a href="images/pc1.jpg" class="b-link-stripe b-animate-go  swipebox">
					<div class="ed-gal-effect slow-zoom horizontal">
						<div class="img-box"><img src="images/pc1.jpg" alt=" " /></div>
							<div class="ed-text-box">
								<div class="ed-gal-text">
									<h4>Hostel</h4>
									<p>It has been a wonderful stay here! It was a relaxing, laugher-filled stay with some amazing people!</p>
								</div>
							</div>
					</div>
				</a>

                </div>
                <div class="col-md-4 filtr-item" data-category="1, 4" data-sort="City wonders">
                    <a href="images/pc2.jpg" class="b-link-stripe b-animate-go  swipebox">
					<div class="ed-gal-effect slow-zoom horizontal">
						<div class="img-box"><img src="images/pc2.jpg" alt=" " /></div>
							<div class="ed-text-box">
								<div class="ed-gal-text">
									<h4>Hostel</h4>
									<p>It has been a wonderful stay here! It was a relaxing, laugher-filled stay with some amazing people!</p>
								</div>
							</div>
					</div>
				</a>

                </div>
                <div class=" col-md-4 filtr-item" data-category="3" data-sort="In production">
                   <a href="images/pc3.jpg" class="b-link-stripe b-animate-go  swipebox">
					<div class="ed-gal-effect slow-zoom horizontal">
						<div class="img-box"><img src="images/pc3.jpg" alt=" " /></div>
							<div class="ed-text-box">
								<div class="ed-gal-text">
									<h4>Hostel</h4>
									<p>It has been a wonderful stay here! It was a relaxing, laugher-filled stay with some amazing people!</p>
								</div>
							</div>
					</div>
				</a>

                </div>
                <div class="col-md-4 filtr-item" data-category="3, 4" data-sort="Industrial site">
                    <a href="images/pc4.jpg" class="b-link-stripe b-animate-go  swipebox">
					<div class="ed-gal-effect slow-zoom horizontal">
						<div class="img-box"><img src="images/pc4.jpg" alt=" " /></div>
							<div class="ed-text-box">
								<div class="ed-gal-text">
									<h4>Hostel</h4>
									<p>It has been a wonderful stay here! It was a relaxing, laugher-filled stay with some amazing people!</p>
								</div>
							</div>
					</div>
				</a>

                </div>
                <div class="col-md-4 filtr-item" data-category="2, 4" data-sort="Peaceful lake">
                    <a href="images/pc5.jpg" class="b-link-stripe b-animate-go  swipebox">
					<div class="ed-gal-effect slow-zoom horizontal">
						<div class="img-box"><img src="images/pc5.jpg" alt=" " /></div>
							<div class="ed-text-box">
								<div class="ed-gal-text">
									<h4>Hostel</h4>
									<p>It has been a wonderful stay here! It was a relaxing, laugher-filled stay with some amazing people!</p>
								</div>
							</div>
					</div>
				</a>

                </div>
                <div class="col-md-4  filtr-item" data-category="1, 5" data-sort="City lights">
                   <a href="images/pc6.jpg" class="b-link-stripe b-animate-go  swipebox">
					<div class="ed-gal-effect slow-zoom horizontal">
						<div class="img-box"><img src="images/pc6.jpg" alt=" " /></div>
							<div class="ed-text-box">
								<div class="ed-gal-text">
									<h4>Hostel</h4>
									<p>It has been a wonderful stay here! It was a relaxing, laugher-filled stay with some amazing people!</p>
								</div>
							</div>
					</div>
				</a>

                </div>
                <div class="col-md-4 filtr-item" data-category="2, 4" data-sort="Dreamhouse">
                   <a href="images/pc7.jpg" class="b-link-stripe b-animate-go  swipebox">
					<div class="ed-gal-effect slow-zoom horizontal">
						<div class="img-box"><img src="images/pc7.jpg" alt=" " /></div>
							<div class="ed-text-box">
								<div class="ed-gal-text">
									<h4>Hostel</h4>
									<p>It has been a wonderful stay here! It was a relaxing, laugher-filled stay with some amazing people!</p>
								</div>
							</div>
					</div>
				</a>

                </div>
				<div class="col-md-4 filtr-item" data-category="3" data-sort="Dreamhouse">
                   <a href="images/pc8.jpg" class="b-link-stripe b-animate-go  swipebox">
					<div class="ed-gal-effect slow-zoom horizontal">
						<div class="img-box"><img src="images/pc8.jpg" alt=" " /></div>
							<div class="ed-text-box">
								<div class="ed-gal-text">
									<h4>Hostel</h4>
									<p>It has been a wonderful stay here! It was a relaxing, laugher-filled stay with some amazing people!</p>
								</div>
							</div>
					</div>
				</a>

                </div>
               <div class="clearfix"> </div>
            </div>
    </div>
</div>

    <!-- Include jQuery & Filterizr -->
    
    <script src="js/jquery.filterizr.js"></script>
    <script src="js/controls.js"></script>

    <!-- Kick off Filterizr -->
    <script type="text/javascript">
        $(function() {
            //Initialize filterizr with default options
            $('.filtr-container').filterizr();
        });
    </script>
	<!--//gallery-->

<!---->
<!--//footer-->
<link rel="stylesheet" href="css/swipebox.css">
<!-- swipe box js -->
	<script src="js/jquery.swipebox.min.js"></script> 
	    <script type="text/javascript">
			jQuery(function($) {
				$(".swipebox").swipebox();
			});
	</script>
<!-- //swipe box js -->

</body>
</html>
<?php include('footer.php');?>