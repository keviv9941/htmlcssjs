-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 31, 2010 at 08:29 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_mgnt`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `book_id` varchar(255) NOT NULL,
  `book_category` varchar(255) NOT NULL,
  `book_name` varchar(255) NOT NULL,
  `book_author` varchar(255) NOT NULL,
  `book_company` varchar(255) NOT NULL,
  `book_price` int(11) NOT NULL,
  `book_ibn` int(11) NOT NULL,
  `book_edition` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `avail` varchar(100) NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`book_id`, `book_category`, `book_name`, `book_author`, `book_company`, `book_price`, `book_ibn`, `book_edition`, `image`, `created`, `avail`) VALUES
('book1234', 'c', 'cpp', 'ttt', 'yuy', 676, 76776, '7', 'book1234@jpg', '2016-10-19 14:16:25', 'yes'),
('book18152', 'c', 'hgd', 'jhg', 'kjh', 8765, 876, '76', 'p1.php', '2016-10-19 14:19:33', 'yes'),
('book27413', 'java', 'Ascii java', 'bala', 'bpb', 300, 765432, '5', '', '2016-10-23 14:55:23', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `student_id` varchar(255) NOT NULL,
  `book_id` varchar(255) NOT NULL,
  `date_of_issue` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_of_return` timestamp NULL DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `student_id`, `book_id`, `date_of_issue`, `date_of_return`, `status`) VALUES
(1, 'stu11944', 'book1234', '2016-10-23 14:52:34', '2016-10-24 18:41:09', 1),
(2, 'stu11944', 'book27413', '2016-10-23 14:56:54', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `limitation`
--

CREATE TABLE `limitation` (
  `id` int(11) NOT NULL,
  `no_of_book` int(11) NOT NULL,
  `no_of_employee` int(11) NOT NULL,
  `no_of_day` int(11) NOT NULL,
  `fine` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `limitation`
--

INSERT INTO `limitation` (`id`, `no_of_book`, `no_of_employee`, `no_of_day`, `fine`) VALUES
(1, 5, 5, 20, 5);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` varchar(255) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `student_email` varchar(255) NOT NULL,
  `student_gender` varchar(255) NOT NULL,
  `student_mobile` int(11) NOT NULL,
  `student_pin` int(11) NOT NULL,
  `student_image` varchar(255) NOT NULL,
  `student_college_id` varchar(255) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `no_of_book` int(11) NOT NULL DEFAULT '0',
  `fine` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_name`, `student_email`, `student_gender`, `student_mobile`, `student_pin`, `student_image`, `student_college_id`, `created`, `no_of_book`, `fine`) VALUES
('stu11944', 'ggg', 'gg@g.conm', 'male', 546, 123456, 'email.txt', '4565', '2016-10-19 14:14:36', 1, 0),
('stu1234', 'student', 'email', 'gender', 6676, 7677, '66776.jpg', '3456789', '2016-10-19 14:09:33', 0, 0),
('stu28058', 'gaurav', 'gauarv1@gmail.com', 'male', 2147483647, 811308, '', '7886', '2016-10-19 14:13:25', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tracking`
--

CREATE TABLE `tracking` (
  `sid` varchar(100) NOT NULL,
  `time_of` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tracking`
--

INSERT INTO `tracking` (`sid`, `time_of`) VALUES
('jhgfdfghjkjhf', '2016-10-24 19:27:30');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `permission` int(11) NOT NULL DEFAULT '1',
  `activtion` int(11) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `mobile`, `email`, `password`, `permission`, `activtion`, `created`) VALUES
(1, 'kumar gaurav', 9045642302, 'gaurav@gmail.com', '29be54a52396750258d886abc5417fda', 1, 1, '2016-10-19 12:21:19'),
(3, 'suraj', 3456789, 'suraj@gmail.com', '2d3c7cd7e9224d7100570660d4530455', 1, 1, '2016-10-19 14:20:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `limitation`
--
ALTER TABLE `limitation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `student_email` (`student_email`);

--
-- Indexes for table `tracking`
--
ALTER TABLE `tracking`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `limitation`
--
ALTER TABLE `limitation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
