<?php include('header.php') ?>

<?php if(!isset($_SESSION['emaila']) || empty($_SESSION['emaila'])){ echo "<script>location.href='index.php';</script>";}?>

<div class="container">
	<div class="page">
<div class="typo-head">
					<h3>Student Information</h3>
					<p> FOR Adding, View, Searching, Deactivation, Edit................</p>
				</div>
		<!--button-->
		
		<div class="">
				<ul class="nav-login1">
					<li><a href="add_student.php" >Add new Student</a></li>
					<li><a href="view_student.php" >View Student</a></li>
					<li><a href="check_student.php" >Check Student</a></li>
				</ul>
			</div>
		
</div>
</div>




<?php include('footer.php') ?>