<?php  include('header.php')?>



	<div class="contact">
		<div class="container">
			<div class="contact-head">
				<h2>Contact Us</h2>	
			</div>
			<div class="contact-grids">
				<div class="col-md-8 map">
					<iframe src="   http://www.maps.ie/create-google-map/map.php?width=100%&amp;height=400&amp;hl=en&amp;q=Ducat%20A-52%20Sector%2016%2C%20Noida+(Library%20management%20System%20By%20Kumar%20Gaurav)&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=A&amp;output=embed"  allowfullscreen></iframe>
				</div>
				<div class="col-md-4 con-grid">
					<div class="contact-grid1">
						<i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>
						<div class="con-ic">
							<p>Shaheed Bhagat Singh State Technical Campus
Moga Road (NH-95), Ferozepur-152004 (Punjab) India<span>Punjab</span></p>
						</div>
							<div class="clearfix"> </div>
					</div>
					<div class="contact-grid contact-grid1">
						<i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>
						<div class="con-ic">
							<p>+91-1632-242138 <span> 91-8288-012050 </span></p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid1">
						<i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
						<div class="con-ic">
							<p><a href="mailto:info@example.com">director@sbsstc.ac.in</a><span><a href="mailto:info@example.com">director@sbsstc.ac.in</a></span></p>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>			
			<form action="#" method="post">
				<div class="contact-grids1">
					<div class="contact-me ">
						<h4>Message</h4>
						<textarea  name="Message"  placeholder="" required=""> </textarea>
					</div>
					<div class="col-md-5 contact-form1">
						<h4>Name</h4>
						<input type="text" name="Name" placeholder="" required="">
					</div>
					<div class="col-md-5 contact-form1">
						<h4>Email</h4>
						<input type="email" name="Email" placeholder="" required="">
					</div>
					<div class="col-md-2 contact-form">
						<input type="submit" value="Submit" >
					</div>
					<div class="clearfix"> </div>
				
				</div>
				</form>
		</div>
	</div>	
	
	
	<?php  include('footer.php')?>