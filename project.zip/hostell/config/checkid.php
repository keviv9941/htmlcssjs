<?php
$book_id=$_POST['se'];
if($book_id!=""){
	include('database.php');
	$q="select * from book where book_id='$book_id' and avail='yes'";
	$r=mysqli_query($link,$q);
	if(mysqli_num_rows($r)>0)
	{
		
	
	
	
		echo "Right";
	}else{
		echo "Wrong";
	}

}







?>