<?php
$book=$_POST['se'];
if($book!=""){
	include('database.php');
	$q="select avail from book where book_id='$book' and avail='no'";
	$r=mysqli_query($link,$q);
	if(mysqli_num_rows($r)>0)
	{
		mysqli_query($link,"update book set avail='yes' where book_id='$book'");
		$r=mysqli_query($link,"select student_id from booking where book_id='$book' and status=0");
		$a=mysqli_fetch_array($r);
		$st=$a['student_id'];
		mysqli_query($link,"update student set no_of_book=no_of_book-1 where student_id='$st'");
		mysqli_query($link,"update booking set status=1,date_of_return=now() where student_id='$st' and book_id='$book' and status=0");
		
	
	
		echo " <h1 class='text-primary text-center form-group  bg-info' style='padding:20px;'  >Successfully Return  </h1>";
	}else{
		echo "<h1 class='text-danger text-center form-group text-uppercase bg-danger' style='padding:20px;'  >No Record Found To booking</h1>";
}}
else{
	echo "<h1 class='text-danger text-center form-group text-uppercase bg-danger' style='padding:20px;'  >No found</h1>";
	
}

?>