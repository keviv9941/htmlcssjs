<?php
session_start();
$link=mysqli_connect("localhost","root","","library_mgnt") or die("not connected");


?>