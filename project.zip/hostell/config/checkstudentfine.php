<?php
$student=$_POST['se'];
if($student!=""){
	include('database.php');
	$q="select fine from student where student_id='$student'";
	$r=mysqli_query($link,$q);
	if(mysqli_num_rows($r)>0)
	{
		$a=mysqli_fetch_array($r);
	
	
	
		echo " <h1 class='text-primary text-center form-group  bg-info' style='padding:20px;'  >Fine:- ".$a['fine'].".00  &#8377;</h1>";
	}else{
		echo "<h1 class='text-danger text-center form-group text-uppercase bg-danger' style='padding:20px;'  >No found</h1>";
}}
else{
	echo "<h1 class='text-danger text-center form-group text-uppercase bg-danger' style='padding:20px;'  >No found</h1>";
	
}

?>