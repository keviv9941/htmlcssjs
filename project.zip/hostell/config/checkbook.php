<?php
$book=$_POST['book'];
if($book!=""){
echo " <thead>
        <tr>
          <th>#</th>
          <th>Image</th>
          <th>Book Name</th>
		  <th>Price</th>
		  <th>avail</th>
		  <th>Details</th>
        </tr>
      </thead>
      <tbody>
      ";
	  { include('database.php');
	  
	
	  
	  $q=" select * from book  where book_id like '$book%' or book_category like '$book%' or book_name like '$book%' or book_author like '$book%' or book_company like '$book%' or book_price like '$book%' or book_ibn like '$book%' or book_edition like '$book%' ";
	
	  $result=mysqli_query($link,$q);
	  if(mysqli_num_rows($result)>0)
	  {
		  $s=1;
		while($a=mysqli_fetch_array($result)){
		
	  
      echo"  <tr>
          <th scope='row'> $s</th>
          <td><img src='images/category/".$a['book_image']."' width='75' ></td>
          <td> ".$a['book_name']."</td>
          <td> ".$a['book_price']."</td>
		  <td>".$a['avail']."</td>
          <td><a href='detail_book.php?id=". $a['book_id']."'>Details</a></td>
        </tr>";
		
	  
		$s++;}
	  }else{ 
	  
	   echo "<tr>
          <th scope='row' colspan='6'><span style='color:red; font-family:chiller; font-size:30px;'>No found</span></th>
          
        </tr>";
	  }}
       
        
        
      echo "</tbody>";
}
else{
	echo "<span style='color:red; font-family:chiller; font-size:30px;'>No found</span>";
	
}

?>