<?php
extract($_POST);
$a=array();
$i=0;
$j=0;
while($i<5)
{
	$x=('b_id'.$i);
	if($_POST[$x]!="")
	{
		$a[$j]=$_POST[$x];
		$j++;
	}
	$i++;
}
if(count($a))
{
	$stu_id=$_POST['stu_id'];
	$q="";
	$i=0;
	while($i<count($a))
	{
		
			
			include("database.php");
			$r=mysqli_query($link,"select * from book where book_id='$a[$i]' and avail='yes'");
			if(mysqli_num_rows($r)>0)
			{
				$q="INSERT INTO `booking` (`book_id`, `student_id`) VALUES ('$a[$i]','$stu_id')";
				mysqli_query($link,$q);
				mysqli_query($link,"UPDATE `student` SET `no_of_book` = no_of_book+1 WHERE `student_id` = '$stu_id'");
				mysqli_query($link,"UPDATE `book` SET `avail` = 'no' WHERE `book_id` = '$a[$i]'");
		
			}
		
		$i++;
	}
	

	
	echo "<script>alert('booked is Issue');location.href='../detail_studentstatus.php?stu_id=".$stu_id."'</script>";
}
?>