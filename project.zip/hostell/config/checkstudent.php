<?php
$student=$_POST['se'];
if($student!=""){
echo " <thead>
        <tr>
          <th>#</th>
          <th>Image</th>
          <th>Student Name</th>
		  <th>College Id</th>
		  <th>No of Book</th>
		  <th>Fine</th>
		  <th>Details</th>
        </tr>
      </thead>
      <tbody>";
	  { include('database.php');
	  
		  
	  $q=" select * from student  where student_id like '$student%' or student_email like '$student%' or student_name  like '$student%' or student_gender like '$student%' or student_mobile like  '$student%' or student_pin  like '$student%' or student_college_id  like '$student%'  ";

	  $result=mysqli_query($link,$q);
	  if(mysqli_num_rows($result)>0)
	  {
		  $s=1;
		while($a=mysqli_fetch_array($result)){
		
	  
      echo"  <tr>
          <th scope='row'> $s</th>
          <td><img src='images/student/".$a['student_image']."' width='75' ></td>
          <td> ".$a['student_name']."</td>
          <td> ".$a['student_college_id']."</td>
		  <td> ".$a['no_of_book']."</td>
		  <td> ".$a['fine']."</td>
          <td><a href='detail_student.php?id=". $a['student_id']."'>Details</a></td>
        </tr>";
		
	  
		$s++;}
	  }else{ 
	  
	   echo "<tr>
          <th scope='row' colspan='6'><span style='color:red; font-family:chiller; font-size:30px;'>No found</span></th>
          
        </tr>";
	  }}
       
        
        
      echo "</tbody>";
}
else{
	echo "<span style='color:red; font-family:chiller; font-size:30px;'>No found</span>";
	
}

?>