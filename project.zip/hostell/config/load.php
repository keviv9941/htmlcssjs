<?php

	include('database.php');

	if(isset($_POST['login']))
	{
		extract($_POST);
		$email=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($email))));
		$password=md5(strip_tags(htmlentities(mysqli_real_escape_string($link,trim($password)))));
		
		$q=" select * from user where email='$email' and password='$password'";
		
		$res=mysqli_query($link,$q);
		if(mysqli_num_rows($res)>0)
		{
			$_SESSION['emaila']=$email;
			echo "<script>location.href='../index.php';</script>";
		}
		else
		{
			echo "<script>alert('unsucsess');location.href='../index.php';</script>";
		
		}
	
	}
	else if(isset($_POST['register']))
	{
		
		extract($_POST);
		$Name=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($Name))));
		$Mobile_number=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($Mobile_number))));
		$Email_id=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($Email_id))));
		$Password=md5(strip_tags(htmlentities(mysqli_real_escape_string($link,trim($Password)))));
		
		
		$q="INSERT INTO `user` ( `name`, `mobile`, `email`, `password`, `permission`, `activtion`) VALUES ( '$Name', '$Mobile_number', '$Email_id', '$Password', '1', '1') ";
		if(mysqli_query($link,$q))
		{
			echo "<script>alert('Sucsessfully Register');location.href='../index.php';</script>";
		}
		else
		{
			echo "<script>alert('Unsucsess');location.href='../index.php';</script>";
		
		}
	
	
	}
	
	else if(isset($_POST['add_student']))
	{
	
		
		extract($_POST);
		$name=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($name))));
		$email=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($email))));
		$gender=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($gender))));
		$mobile=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($mobile))));
		$pin=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($pin))));
		$stu_clg_id=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($stu_clg_id))));
		$stu_id="stu".rand();
		$image_name=$_FILES['image']['name'];
		$q="INSERT INTO `student` (`student_id`, `student_name`, `student_email`, `student_gender`, `student_mobile`, `student_pin`, `student_image`, `student_college_id`) VALUES ('$stu_id', '$name', '$email', '$gender', '$mobile', '$pin', '$image_name', '$stu_clg_id');";
		if(mysqli_query($link,$q))
		{
			echo "<script>alert('Sucsessfully Added Student');location.href='../add_student.php';</script>";
		}
		else
		{
			echo "<script>alert('Some think Error');location.href='../add_student.php';</script>";
		
		}
	
	
	}
	
	else if(isset($_POST['add_book']))
	{
		
		extract($_POST);
		$category=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($category))));
		$book=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($book))));
		$author=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($author))));
		$company=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($company))));
		$price=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($price))));
		$ibn=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($ibn))));
		$edition=strip_tags(htmlentities(mysqli_real_escape_string($link,trim($edition))));
		
		$image_name=$_FILES['image']['name'];
		
		$book_id="book".rand();
		$q="INSERT INTO `book` (`book_id`, `book_category`, `book_name`, `book_author`, `book_company`, `book_price`, `book_ibn`, `book_edition`, `image`) VALUES ('$book_id', '$category', '$book', '$author', '$company', '$price', '$ibn', '$edition', '$image_name');";
		if(mysqli_query($link,$q))
		{
			echo "<script>alert('Sucsessfully Added Book');location.href='../add_book.php';</script>";
		}
		else
		{
			echo "<script>alert('Some think Error');location.href='../add_book.php';</script>";
		
		}
	
	
	}













?>