<?php include('header.php')?>
<?php if(!isset($_SESSION['emaila']) || empty($_SESSION['emaila'])){ echo "<script>location.href='index.php';</script>";}?>
<div class="container">
	<div class="page">
<div class="page-header">
<?php  if(!isset($_GET['id']))
		header('location:check_book.php');
	else
	{
		$id=$_GET['id'];
		include('config/database.php');
		$q="select * from book where book_id='$id'";
		$res=mysqli_query($link,$q);
		if(mysqli_num_rows($res)>0)
		{
			$a=mysqli_fetch_array($res);
	?>
        <h3> Book Details</h3><h4 style="margin-left:80%; "><a href="book.php"> &lt;&lt;&nbsp;&nbsp; Back</a></h4>
      </div>
  <div class="bs-example " data-example-id="simple-horizontal-form">
    <form class="form-horizontal">
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Category</label>
        <div class="col-sm-10">
         <input type="text" readonly value="<?=$a['book_category'] ?>" class="form-control" id="inputEmail3" placeholder="Category">
        </div>
      </div>
	
      <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">BOOk Name</label>
        <div class="col-sm-10">
          <input type="text" readonly name="book" class="form-control"  value="<?=$a['book_name'] ?>" id="inputEmail3" placeholder="Book Name....">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Author Name</label>
        <div class="col-sm-10">
          <input type="text" readonly name="author" class="form-control"  value="<?=$a['book_author'] ?>" id="inputEmail3" placeholder="Author Name.....">
        </div>
      </div><div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Company Name</label>
       <div class="col-sm-10">
          <input type="text" readonly name="company" class="form-control"  value="<?=$a['book_company'] ?>" id="inputEmail3" placeholder="Company Name ............">
        </div>
		</div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Price</label>
        <div class="col-sm-10">
          <input type="number" readonly  name="price" class="form-control"  value="<?=$a['book_price'] ?>" id="inputEmail3" placeholder="Price ............">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">IBN no:-</label>
        <div class="col-sm-10">
          <input type="number" readonly name="ibn"  class="form-control"  value="<?=$a['book_ibn'] ?>" id="inputEmail3" placeholder="IBN no ..............">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Edition</label>
        <div class="col-sm-10">
          <input type="text" readonly name="edition"  class="form-control" id="inputEmail3"  value="<?=$a['book_edition'] ?>" placeholder="Edition ..............">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Image</label>
        <div class="col-sm-10">
          <img src="" width="100" height="100">
        </div>
      </div>
      <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Status</label>
        <div class="col-sm-10">
         <input type="text" readonly name="edition"  class="form-control" id="inputEmail3"  value="<?=$a['avail'] ?>" placeholder="Edition ..............">
        </div>
      </div>
      
      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <a href="book.php"><input type="button"  class="btn btn-primary " value="!  Back  !"></a>
        </div>
      </div>
		</form><?php }
		else{
			echo "<script> alert('error detail');location.href='check_book.php'</script>";
			
		}
		
		}?>
  </div>
</div>
</div>

<?php include('footer.php')?>