<?php  include('header.php') ?>

<div class="container">
	<div class="page">
		<div><h4 align="center">Student Hostels</h4></div>
		<div>The Technical Campus has four hostels for boys namely Satluj Bhawan, Ganga Bhawan,Yammuna Bhawan and Beas Bhawan and Two hostel for girls namely Mata Gujari Bhawan And Sarsawati Bhawan.  Following are the main features of these hostels:</div>
		<div>1. Satluj Bhawan and Ganga Bhawan have 91 dormitory rooms each with a capacity of 3 to 4 students, while Beas Bhawan has 202 double seater rooms.<br>

2. Each Hostel has a TV room with cable connection, a guest room, a room for-in-door games and a recreation cum reading room.<br>

3. Each hostel has a warden office and a manager’s office for its smooth functioning.<br>

4. Each hostel is running co-operative mess. Students themselves ensure the quality of the food served, decide the menu and manage all the matters.
<br>

5. The reading room of each hostel subscribes many magazines and newspapers.<br>

6. Beautifully landscaped lawns are developed in front of each hostel providing students eye-soothing and refreshing surroundings.<br>

7. Girls hostels have 29 dormitory rooms each with a capacity of 3 to 4 students and 79 two seater rooms. <br>
8. The girls hostels are also provided with the same facilities as described above for boys hostels. <br>
9. In addition to that one badminton court is also provided inside the Saraswati Bhawan.</div><br>
		<div><h4 align="center">Hostel Rules</h4></div>
		<div>1. Students are advised not to keep the any Jewelry it Students are advised not to keep the em, Cash or any other valuable item with him in hostel. Still if they keep, the hostel authorities shall not
responsible for this in case of any theft or loss or damage etc.<br>
2. Playing OUTDOOR games are not allowed to play insid Playing OUTDOOR games are not allowed to play inside ng OUTDOOR games are not allowed to play inside and near and near the hostel at all. near the hostel at all. the hostel at all.<br>
3. Playing AUDIO / VEDIO devices and other Electrical Appliances as Air- Appliances as Air-Cooler , Room Heater are restricted. Cooler , Room Heater are restricted. Cooler , Room Heater are restricted.<br>
4. Lock therooms / Almira rooms / Almira rooms / Almira etc while leaving the room.<br>
5. ROOM CLEANINESS IS NECESSARY. ROOM CLEANINESS IS NECESSARY. ESSARY.<br>
6. This is the duty of every student to inform the war inform the warden inform the warden or Gate-Keeper immediately in cas den e any student of their room (Room Partner) not found in Room / Hostel.<br>
7. Everyone should be in Proper Dress should be in Proper Dress should be in Proper Dress (1) while taking meals in Mess, (2) while going to Office of Warden / Mess-Manager. (Sikh student must be in Turban or Patka
on their head).<br>
8. The timing for T.T Room is T.T Room is T.T Room is 12:30PM to 2 PM to 2 PM to 2PM & 05:30 PM to 10 PM. PM & 05:30 PM to 10 PM. PM & 05:30 PM to 10 PM. (Till next notice)<br>
9. The timing for T.V Room Is 0 T.V Room Is 0 T.V Room Is 05:30AM to 08 AMthen 12:00 Noon 12:00 Noon 12:00 Noon –02 PMand then 05:30 PM to 10 PM 05:30 PM to 10 PM 05:30 PM to 10 PM (Till next notice).<br>
10. The timing for Mess is as under
Monday to Monday toFriday Friday Friday 07.30 AM to 0 07.30 AM to 08 07.30 AM to 08.30AM 12.30 PM to 0 12.30 PM to 0 PM to 01:30 PM 08:00 PM 08:00 PM 08:00 PMto 09:00 to 09:00 to 09:00PM
Saturday, Sunday Saturday, Sunday(Lunch-Brunch) Brunch) Brunch) 09:00AM to 10:00AM to 10:00AM to 10:00AM 01:00 PM to 0 :00 PM to 02:00 :00 PM to 02:00PM 08:00 PM to 09:00 PM 08:00 PM to 09:00 <br>
11. Students are not allowed to take the mess Utensils not allowed to take the mess Utensils outside not allowed to take the mess Utensils outside the M outside <br>
12. Students are not allowed to Ride the Motor not allowed to Ride the Motor not allowed to Ride the Motor-Cycle, Scooter etc inside the Building of Hostel Cycle, Scooter etc inside the Building of Hostel Cycle, Scooter etc inside the Building of Hostel.<br>
13. Students must have to get the Electrical items (as well as Civil work ) of their respective rooms repaired themselves (as Fan Rewinding, Switches, Holders etc) at
their own cost.<br>
14. SMOKING & TAKING INTOXICANTS IS STRICTLY PROHIBITED IN HOSTEL PREMISES. IN HOSTEL PREMISES.<br>
15. THE TIME TO DEPOSIT MESS BILLS to MES THE TIME TO DEPOSIT MESS BILLS to MES TIME TO DEPOSIT MESS BILLS to MESS MANAGER (in Room S MANAGER (in Room No:201) IS 11:0 S MANAGER (in Room No:201) IS 11:00 AM TO 1:30 PM O No:201) IS 11:00 AM TO 1:30 PM ONLY 0 AM TO 1:30 PM ONLY<br>
16. Gate Entry is compulsory while leaving and entering the hostel.<br>
17. Outsiders are not allowed to live in Hostel (in student’s rooms). If any have to live in room with students he must have a written permission from warden/ Chief
 Warden otherwise the fine of Rs100 will be charged.<br>
18. Every student/ hostler is restricted to present in roll call at main gate at night (09:00PM to 10 PM) and mark his attendance in Attendance register having with the
gate keeper every day; else he will be fined of Rs.5 per day.<br>
19. Student can get the study material from the gate keeper and have to return within two days after that the fine of Rs 5/- will be charged per day.<br>
20. Room inventory form will be filled by hostel authorities in presence of the students.Entry time conditions of all items issued to the students will be clearly mentioned
in the form. At the time of vacating the room, student shall hand over all items in the same condition as at entry time. In case of breakage/damage/theft/loss of the
room items, the student shall be liable to pay breakage fine mentioned in the inventory form or as decided by the hostel authorities.<br>
21. Consumption of alcohol or any other intoxicants is strictly banned in the hostel. Defaulters will be strictly punished, can be even expelled from the hostel.<br>
22. Students are to maintain high standards of discipline. If anybody indulges in any act of indiscipline, strict action will be taken & can be even expelled from the
hostel. The decision of hostel/college authorities shall be final & binding in all such cases.<br>
23. This list is not an exhaustive documentation of the hostel rules but is just an indicative sample. Hostel rules are subject to revision from time to time. Also the
instructions passed by the Warden/Hostel authorities from time to time shall be deemed as prevalent hostel rules. So all students are bound to abide the same in
letter & spirit.<br> </div>


		<div class="team">
	<div class="container">
		<h3 >Our Teachers</h3>
		<div class="col-md-3 bottom-grid ">
			<div class="btm-right">
				<img src="images/a2.jpg" alt=" ">
					<div class="captn">
						<div class="captn1">
							<h4>Avinash</h4>
							
						</div>
						<div class="captn2">
							<a href="#" class="icon_1"></a>
							<a href="#" class="icon_2"></a>
							<a href="#" class="icon_3"></a>
							
						</div>
					</div>
			</div>
		</div>
		<div class="col-md-3 bottom-grid ">
			<div class="btm-right">
				<img src="images/tt2.png" alt=" ">
					<div class="captn">
						<div class="captn1">
							<h4>Aakash</h4>
							
						</div>
						<div class="captn2">
							<a href="#" class="icon_1"></a>
							<a href="#" class="icon_2"></a>
							<a href="#" class="icon_3"></a>
								
						</div>
					</div>
			</div>
		</div>
		<div class="col-md-3 bottom-grid ">
			<div class="btm-right">
				<img src="images/su2.jpeg" alt=" ">
					<div class="captn">
						<div class="captn1">
							<h4>Subrat</h4>
							
						</div>
						<div class="captn2">
							<a href="#" class="icon_1"></a>
							<a href="#" class="icon_2"></a>
							<a href="#" class="icon_3"></a>
								
						</div>
					</div>
			</div>
		</div>
		<div class="col-md-3 bottom-grid ">
			<div class="btm-right">
				<img src="images/tt4.png" alt=" ">
					<div class="captn">
						<div class="captn1">
							<h4>Divik</h4>
							
						</div>
						<div class="captn2">
							<a href="#" class="icon_1"></a>
							<a href="#" class="icon_2"></a>
							<a href="#" class="icon_3"></a>
								
						</div>
					</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>	
<div class="test">
		<div class="container">
		<h3>Testimonials</h3>
			<div  class=" test-grid-1" >
				<div class="col-md-6 test-wrapper">
					<img src="images/avi.jpg" alt="" class="img-responsive">
					<div class="test-grid">
					<div class="test-gr">
						<h4>Avinash</h4>
						<span>Director</span>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="col-md-6 test-wrapper">
					<img src="images/aak.jpg" alt="" class="img-responsive">
					<div class="test-grid">
					<div class="test-gr">
						<h4>Aakash</h4>
						<span> Chife Warden</span>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
					</div>
					<div class="clearfix"></div>
				</div>
				
			<div class="clearfix"> </div>
			</div>
			<div  class=" test-grid-2" >
				<div class="col-md-6 test-wrapper">
					<img src="images/sub.jpg" alt="" class="img-responsive">
					<div class="test-grid">
					<div class="test-gr">
						<h4>Subrat</h4>
						<span>Warden</span>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="col-md-6 test-wrapper">
					<img src="images/div.jpg" alt="" class="img-responsive">
					<div class="test-grid">
					<div class="test-gr">
						<h4>Divik</h4>
						<span>Manager</span>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
					</div>
					<div class="clearfix"></div>
				</div>
				
			<div class="clearfix"> </div>
			</div>
		</div>
	</div>
</div>
</div>




<?php  include('footer.php') ?>