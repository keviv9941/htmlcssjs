<?php include('header.php')?>
<?php if(!isset($_SESSION['emaila']) || empty($_SESSION['emaila'])){ echo "<script>location.href='index.php';</script>";}?>
<div class="container">
	<div class="page">
<div class="page-header">
        <h3>View Worker</h3><h4 style="margin-left:80%; "><a href="book.php"> &lt;&lt;&nbsp;&nbsp; Back</a></h4>
      </div>
	
	
  
  <div class="bs-example " data-example-id="simple-table">
    <table class="table">
      
      <thead>
        <tr>
          <th>#</th>
          <th>Image</th>
          <th>Worker Name</th>
		  <th>Salary</th>
		  <th>avail</th>
		  <th>Details</th>
        </tr>
      </thead>
      <tbody>
	  <?php include('config/database.php');
	  
	  $q=" select * from book limit 0,10";
	  $result=mysqli_query($link,$q);
	  if(mysqli_num_rows($result)>0)
	  {
		  $s=1;
		while($a=mysqli_fetch_array($result)){
	  ?>
        <tr>
          <th scope="row"><?= $s;?></th>
          <td><img src="images/category/<?= $a['book_image']?>" width="75" ></td>
          <td><?= $a['book_name']?></td>
          <td><?= $a['book_price']?></td>
		  <td>Yes</td>
          <td><a href="detail_book.php?id=<?= $a['book_id']?>">Details</a></td>
        </tr>
		
	  <?php 
		$s++;}
	  }else{ ?>
	  
	   <tr>
          <th scope="row" colspan="6"><span style="color:red; font-family:chiller; font-size:30px;">No found</span></th>
          
        </tr>
	  <?php }?>
        <tr>
          <th scope="row">2</th>
          <td><img src="images/category/cpp.png" width="75" ></td>
          <td>C ++</td>
          <td>450</td>
		  <td>No</td>
          <td><a href="#">Details</a></td>
        </tr>
        <tr>
          <th scope="row">3</th>
          <td><img src="images/category/java.png" width="75" ></td>
          <td>JAVA</td>
          <td>500</td>
		  <td>Yes</td>
          <td><a href="#">Details</a></td>
        </tr>
        
      </tbody>
    </table>
  </div>
	
  
  
  </div>
</div>
</div>

<?php include('footer.php')?>