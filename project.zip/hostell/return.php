<?php include('header.php')?>
<?php if(!isset($_SESSION['emaila']) || empty($_SESSION['emaila'])){ echo "<script>location.href='index.php';</script>";}?>



<div class="container">
	
<div class="page-header">
        <h3>Return Book</h3><h4 style="margin-left:80%; "><a href="service.php"> &lt;&lt;&nbsp;&nbsp; Back</a></h4>
      </div>
	
	<form class="form-horizontal">
	 <div class="bs-example " data-example-id="simple-table">
		<div id="tar"></div>
  </div>
  <div class="form-group">
        <label for="inputEmail3" style="font-family:chiller;font-size:20px;" class="col-sm-2 control-label">Book ID....!!</label>
        <div class="col-sm-10">
          <input type="search" class="form-control" id="ser"  placeholder="Return Book....">
        </div>
      </div>
	  
	  <div class="form-group">
        <div class="col-sm-offset-10 col-sm-10">
          <button type="submit" id="return" class="btn btn-info ">!  Return  !</button>
        </div>
      </div>
	  </form>
 
	
  
  
  </div>
</div>
</div>

<?php include('footer.php')?>
<script>
$(document).ready(function()
  {
	$("#return").click(function()
	{
		var ser=$("#ser").val();
	$.post("config/returnbook.php",{'se':ser},function(data)
	{
		$("#tar").html(data);
	});
	return false;
	})
  })

</script>