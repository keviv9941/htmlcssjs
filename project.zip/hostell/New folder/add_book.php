<?php include('header.php')?>
<?php if(!isset($_SESSION['emaila']) || empty($_SESSION['emaila'])){ echo "<script>location.href='index.php';</script>";}?>
<div class="container">
	<div class="page">
<div class="page-header">
        <h3>Add New Book</h3><h4 style="margin-left:80%; "><a href="book.php"> &lt;&lt;&nbsp;&nbsp; Back</a></h4>
      </div>
  <div class="bs-example " data-example-id="simple-horizontal-form">
    <form class="form-horizontal" method="post" action="config/load.php" enctype="multipart/form-data">
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Category</label>
        <div class="col-sm-10">
          <select class="form-control" name="category" id="inputEmail3" >
		  <option value="c"> C</option>
		  <option value="c++"> C++</option>
		  <option value="java"> JAVA</option>
		  <option value="c-sharp"> C-SHARP</option>
		  </select>
        </div>
      </div>
	
      <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">BOOk Name</label>
        <div class="col-sm-10">
          <input type="text" name="book" class="form-control" id="inputEmail3" placeholder="Book Name....">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Author Name</label>
        <div class="col-sm-10">
          <input type="text" name="author" class="form-control" id="inputEmail3" placeholder="Author Name.....">
        </div>
      </div><div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Company Name</label>
       <div class="col-sm-10">
          <input type="text" name="company" class="form-control" id="inputEmail3" placeholder="Company Name ............">
        </div>
		</div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Price</label>
        <div class="col-sm-10">
          <input type="number"  name="price" class="form-control" id="inputEmail3" placeholder="Price ............">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">IBN no:-</label>
        <div class="col-sm-10">
          <input type="number" name="ibn"  class="form-control" id="inputEmail3" placeholder="IBN no ..............">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Edition</label>
        <div class="col-sm-10">
          <input type="text" name="edition"  class="form-control" id="inputEmail3" placeholder="Edition ..............">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Image</label>
        <div class="col-sm-10">
          <input type="File" name="image" class="form-control" id="inputPassword3" >
        </div>
      </div>
      
      
      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" name="add_book" class="btn btn-primary ">!  Add Book  !</button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>

<?php include('footer.php')?>