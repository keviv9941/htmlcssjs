<?php include('header.php'); ?>
<div class="container">
	<div class="page">
		<div class="page-header">
		<h3>Details</h3>
</div>
<?php

$stu_id=$_GET['stu_id'];
include('config/database.php');
$r4=mysqli_query($link,"select * from student where student_id='$stu_id'");
if(mysqli_num_rows($r4)>0)
{
?>

<div class="bs-example " data-example-id="simple-table">
    <table class="table">
      
		<thead>
			<tr>
				<th>Student Detail</th><th>Book Detail</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>
					<?php 
						$q1="select * from student where student_id='$stu_id'";
						$r1=mysqli_query($link,$q1);
						$stu=mysqli_fetch_array($r1);?>
						
						<div class="form-group">
							<label class="col-sm-6">Student name</label>
							<div class="col-sm-6"><?= $stu['student_name']?></div>
						</div>
						
						<div class="form-group">
							<label class="col-sm-6">College ID</label>
							<div class="col-sm-6"><?= $stu['student_college_id']?></div>
						</div>
						
						<div class="form-group">
							<label class="col-sm-6">Student Email</label>
							<div class="col-sm-6"><?= $stu['student_email']?></div>
						</div>
				
				</td>
	
				<td>
					<?php 
						
						
						$q1="select * from book where book_id in (select book_id from booking where student_id='$stu_id' and status=0)";
						$r1=mysqli_query($link,$q1);
						$record=0;
						if(mysqli_num_rows($r1)>0){
						while($stu=mysqli_fetch_array($r1)){$record++;?>
						
						<div class="form-group">
							<label class="col-sm-2">name</label>
							<div class="col-sm-2"><?= $stu['book_name']?></div>
						</div>
						
						<div class="form-group">
							<label class="col-sm-2">category</label>
							<div class="col-sm-1"><?= $stu['book_category']?></div>
						</div>
						
						<div class="form-group">
							<label class="col-sm-2">ibn</label>
							<div class="col-sm-1"><?= $stu['book_ibn']?></div>
						</div>
						<?php }}else{?>
				<span style="color:red; font-family:chiller; font-size:30px;">No Book issue</span>
						<?php }?>
				</td>
</tr>

<?php if($record<5){$r=$record; ?>

<tr>
<td colspan="2">

<div class="page-header">
        <h3>Issue book</h3>
      </div>
  <div class="bs-example " data-example-id="simple-horizontal-form">
    <form class="form-horizontal" method="post" name="frm11" action="config/addissue.php">
	<?php while($r!=5){ ?>
      <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Book ID</label>
        <div class="col-sm-8">
          <input type="text" name="b_id<?=$r ?>" class="form-control checkid" placeholder="Enter Book Id........">
		  
        </div>
		
      </div>
	  
	<?php $r++;}?>
	<input type="hidden" name="stu_id" value="<?=$stu_id?>">
	<span id="msg_body"></span>
	  <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" name="add_issue" class="btn btn-primary ">!  Issue  !</button>
        </div>
      </div>
    </form>
  </div>







</td>


</tr>


<?php }}



else
{
	echo "<script> alert('error detail');location.href='issue.php'</script>";
	
}
?>

			
		</tbody>

</table>


</div>
	</div>
</div>

<?php include('footer.php'); ?>
<script>
$(document).ready(function()
  {
	$(".checkid").blur(function()
	{
		var ser=$(this).val();
		var name=$(this).attr("name");
	$.post("config/checkid.php",{'se':ser},function(data)
	{
		
		if(data=="Wrong"){
			alert("Wrong Input Book Id Or already Booked");
		document.getElementsByName(name)[0].value="";
		document.getElementsByName(name)[0].focus();
		
		}
	});
	});
  });

</script>