<?php include('header.php')?>
<?php if(!isset($_SESSION['emaila']) || empty($_SESSION['emaila'])){ echo "<script>location.href='index.php';</script>";}?>
<div class="container">
	<div class="page">
<div class="page-header">

<?php  if(!isset($_GET['id']))
		header('location:check_student.php');
	else
	{
		$id=$_GET['id'];
		include('config/database.php');
		$q="select * from student where student_id='$id'";
		$res=mysqli_query($link,$q);
		if(mysqli_num_rows($res)>0)
		{
			$a=mysqli_fetch_array($res);
	?>
        <h3>Student Details</h3><h4 style="margin-left:80%; "><a href="student.php"> &lt;&lt;&nbsp;&nbsp; Back</a></h4>
      </div>
  <div class="bs-example " data-example-id="simple-horizontal-form">
    <form class="form-horizontal" >
      <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Name</label>
        <div class="col-sm-10">
          <input type="text"  value="<?=$a['student_name'] ?>" readonly name="name" class="form-control" id="inputEmail3" placeholder="Name">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
        <div class="col-sm-10">
          <input type="email"  value="<?= $a['student_email']?>" readonly name="email" class="form-control" id="inputEmail3" placeholder="Email">
        </div>
      </div><div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Gender</label>
         <div class="col-sm-10">
          <input type="text" value="<?= $a['student_gender']?>"   readonly name="mobile" class="form-control" id="inputEmail3" placeholder="Mobile Number">
        </div>
        
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Mobile</label>
        <div class="col-sm-10">
          <input type="number"  value="<?=$a['student_mobile'] ?>" readonly name="mobile" class="form-control" id="inputEmail3" placeholder="Mobile Number">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Pin Code</label>
        <div class="col-sm-10">
          <input type="number"  value="<?= $a['student_pin']?>" readonly name="pin" min="100000" max="999999" title="Please Enter Valid Pin Code " class="form-control" id="inputEmail3" placeholder="Pin Code">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Image</label>
        <div class="col-sm-10">
          <img src="" width="100" height="100"
        </div>
      </div>
     <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Student College Id</label>
        <div class="col-sm-10">
          <input type="text"  value="<?= $a['student_college_id']?>" readonly name="stu_clg_id" class="form-control" id="inputPassword3" >
        </div>
      </div>
	  <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">No of book Issued</label>
        <div class="col-sm-10">
          <input type="text"  value="<?= $a['no_of_book']?>" readonly name="stu_clg_id" class="form-control" id="inputPassword3" >
        </div>
      </div>
       <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Fine</label>
        <div class="col-sm-10">
          <input type="text"  value="<?= $a['fine']?>" readonly name="stu_clg_id" class="form-control" id="inputPassword3" >
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <a href="book.php"><input type="button"  class="btn btn-primary " value="!  Back  !"></a>
        </div>
      </div>
		</form><?php }
		else{
			echo "<script> alert('error detail');location.href='check_student.php'</script>";
			
		}
		
		}?>
  </div>
</div>
</div>
</div>
<?php include('footer.php')?>