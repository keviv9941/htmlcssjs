<?php include('header.php')?>
<?php if(!isset($_SESSION['emaila']) || empty($_SESSION['emaila'])){ echo "<script>location.href='index.php';</script>";}?>



<div class="container">
	
<div class="page-header">
        <h3>Check Student Fine</h3><h4 style="margin-left:80%; "><a href="service.php"> &lt;&lt;&nbsp;&nbsp; Back</a></h4>
      </div>
	
	<form class="form-horizontal">
  <div class="form-group">
        <label for="inputEmail3" style="font-family:chiller;font-size:20px;" class="col-sm-2 control-label">Student Id....!!</label>
        <div class="col-sm-10">
          <input type="search" class="form-control" id="ser"  placeholder="Search For student Fine....">
        </div>
      </div>
	  
	  <div class="form-group">
        <div class="col-sm-offset-10 col-sm-10">
          <button type="submit" id="fine" class="btn btn-info ">!  Check Fine  !</button>
        </div>
      </div>
	  </form>
  <div class="bs-example " data-example-id="simple-table">
    <table class="table" id="tar">
      
         </table>
  </div>
	
  
  
  </div>
</div>
</div>

<?php include('footer.php')?>
<script>
$(document).ready(function()
  {
	$("#fine").click(function()
	{
		var ser=$("#ser").val();
	$.post("config/checkstudentfine.php",{'se':ser},function(data)
	{
		$("#tar").html(data);
	});
	return false;
	})
  })

</script>