<?php include('header.php') ?>
<?php if(!isset($_SESSION['emaila']) || empty($_SESSION['emaila'])){ echo "<script>location.href='index.php';</script>";}?>


<div class="container">
	<div class="page">
<div class="typo-head">
					<h3>Services For Hostel </h3>
					<p> For Issue, Return and Fine Check ................</p>
				</div>
		<!--button-->
		
		<div class="">
				<ul class="nav-login1">
					<li><a href="issue.php" >Service Book</a></li>
					<li><a href="return.php">Service Control</a></li>
					<li><a href="fine.php" >Check Fine</a></li>
					<li><a href="mess.php" >Mess Bill</a></li>
					<li><a href="mess.php">&nbsp;&nbsp;&nbsp;&nbsp;Room Allotment</a></li>
				</ul>
			</div>
		
</div>
</div>




<?php include('footer.php') ?>