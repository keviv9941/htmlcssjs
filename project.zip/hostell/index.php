<?php include('header.php');?>


	<div class="container">
	<div class="page">
<div class="typo-head">
					<h3>Welcome to my Hostel Management System</h3>
					<p> There are many variations of Facilities are here................</p>
				</div>
		<!--button-->
		
</div>
</div>

<?php include('footer.php');?>