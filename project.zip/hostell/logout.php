<?php
session_start();
session_unset($_SESSION['emaila']);
unset($_SESSION['emaila']);
session_destroy();
header('location:index.php');



?>