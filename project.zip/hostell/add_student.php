<?php include('header.php')?>
<?php if(!isset($_SESSION['emaila']) || empty($_SESSION['emaila'])){ echo "<script>location.href='index.php';</script>";}?>
<div class="container">
	<div class="page">
<div class="page-header">
        <h3>Add New Student</h3><h4 style="margin-left:80%; "><a href="student.php"> &lt;&lt;&nbsp;&nbsp; Back</a></h4>
      </div>
  <div class="bs-example " data-example-id="simple-horizontal-form">
    <form class="form-horizontal" method="post" action="config/load.php" enctype="multipart/form-data">
      <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Name</label>
        <div class="col-sm-10">
          <input type="text" name="name" class="form-control" id="inputEmail3" placeholder="Name">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
        <div class="col-sm-10">
          <input type="email" name="email" class="form-control" id="inputEmail3" placeholder="Email">
        </div>
      </div><div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Gender</label>
        <div class="col-sm-1">
          <input type="radio" class="form-control" id="inputEmail3" name="gender" checked value="male"></div><label for="inputEmail3" class="col-sm-1 control-label">MALE</label>
		<div class="col-sm-1">
		 <input type="radio" class="form-control" id="inputEmail3" name="gender" value="female"></div>
		 <label for="inputEmail3" class="col-sm-1 control-label">FEMALE</label>
        
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Mobile</label>
        <div class="col-sm-10">
          <input type="number" name="mobile" class="form-control" id="inputEmail3" placeholder="Mobile Number">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Pin Code</label>
        <div class="col-sm-10">
          <input type="number" name="pin" min="100000" max="999999" title="Please Enter Valid Pin Code " class="form-control" id="inputEmail3" placeholder="Pin Code">
        </div>
      </div>
	  <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Image</label>
        <div class="col-sm-10">
          <input type="File" name="image" class="form-control" id="inputPassword3" >
        </div>
      </div>
     <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Student College Id</label>
        <div class="col-sm-10">
          <input type="text" name="stu_clg_id" class="form-control" id="inputPassword3" >
        </div>
      </div>
      <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Room No</label>
        <div class="col-sm-10">
          <input type="text" name="no_of_book" class="form-control" id="inputPassword3" >
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" name="add_student" class="btn btn-primary ">!  Add Student  !</button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>

<?php include('footer.php')?>