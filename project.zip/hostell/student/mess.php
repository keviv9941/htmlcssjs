<?php include('header.php') ?>
<?php if(!isset($_SESSION['emaila']) || empty($_SESSION['emaila'])){ echo "<script>location.href='index.php';</script>";}?>


<div class="container">
	<div class="page">
<div class="typo-head">
					<h3>Services For Hostel </h3>
				</div>
		<!--button-->
		
		<div class="">
				<ul class="nav-login1">
					<li><a href="Beas.php" >Beas Hostel</a></li>
					<li><a href="Yammuna.php" >Yammuna Hostel</a></li>
					<li><a href="Satluj.php" >Satluj Hostel</a></li>
					<li><a href="Ganga.php" >Ganga Hostel</a></li>
					<li><a href="MataGujari.php" >MataGujari Hostel</a></li>
				</ul>
			</div>
		
</div>
</div>




<?php include('footer.php') ?>