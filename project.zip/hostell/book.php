<?php include('header.php') ?>
<?php if(!isset($_SESSION['emaila']) || empty($_SESSION['emaila'])){ echo "<script>location.href='index.php';</script>";}?>


<div class="container">
	<div class="page">
<div class="typo-head">
					<h3>Workers Information For Hostel </h3>
					<p> For Issue, Return and Fine Check ................</p>
				</div>
		<!--button-->
		
		
		<div class="">
				<ul class="nav-login1">
					<li><a href="add_book.php" >AddWorker</a></li>
					<li><a href="view_book.php" >View Worker</a></li>
					<li><a href="check_book.php" >Check Availablity</a></li>
				</ul>
			</div>
		
</div>
</div>




<?php include('footer.php') ?>