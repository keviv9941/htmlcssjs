
<!--footer-->
<div class="footer">
	<div class="container">
		<div class="col-md-6 footer-left">
			<h3>Information</h3>
			<p class="para">This is Hostel Management System.</p>
			<form action="#" method="post">
				<input type="text" value="Name" name="Name">
				<input type="email" value="Email" name="Email">
				<input type="submit" value="Submit">
			</form>
		</div>
		<div class="col-md-6 footer-right">
			<h3>Contact Us</h3>
			<ul class="con-icons">
				<li><span class="glyphicon glyphicon-phone" aria-hidden="true"></span>+123 456 7890</li>
				<li><a href="mailto:info@example.com"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>director@sbsstc.ac.in</a></li>
			</ul>
			<p class="copy-right">© 2016 Academic. All rights reserved | Design by Our Team</a></p>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!--//footer-->
</body>
</html>